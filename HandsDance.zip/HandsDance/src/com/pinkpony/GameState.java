package com.pinkpony;

public enum GameState {

	PLAY,
	MENU,
	PAUSED,
	LEVELONE, 
	EXIT,
	LEVELTWO, LEVELCOMPLETE;
}
