package com.pinkpony;

import java.awt.Color;
import java.awt.Graphics;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class StateChanger {

	Graphics gr;
	public static GameState gameState;
	private MainMenu mainmenu;
	private AbstractGameState play;
	private AbstractGameState pause;
	private AbstractGameState levelOne;
	private AbstractGameState levelTwo;
	private AbstractGameState levelComplete;
    private static AudioStream audioStream;
	private static boolean isPlaying = false;
	private boolean sleeping = true;
	
	public StateChanger()
	{
		mainmenu = new MainMenu();
		play = new Play();
		pause = new Pause();
		levelOne = new LevelOne();
		levelTwo = new LevelTwo();
		gameState = GameState.MENU;
		levelComplete = new LevelComplete();
		
		if (audioStream == null) {
			try
	        {
				InputStream in = new FileInputStream(new File("./music/Technologic.wav"));
		        audioStream = new AudioStream(in);
		        isPlaying = false;
		    } 
			catch (IOException e)
	        {
	            e.printStackTrace();
	        }
		}
	}
	
	public void tick(Graphics g)
	{
		gr = g;
//		gr.clearRect(0, 0, HandsDance.WIDTH, HandsDance.HEIGHT);
//		gr.setColor(Color.PINK);
//		gr.drawString("HandsDance : Pink Pony", 150, 20);
//		gr.drawString("HIT ESC TO LEAVE", 10, 20);	
	
		switch(gameState)
		{
			case MENU:
				mainmenu.tick(gr);
				break;
			case PAUSED:
				pause.tick(gr);
				break;
			case PLAY:
				play.tick(gr);
				break;	
			case LEVELONE:
				levelOne.tick(gr);
				break;
			case LEVELTWO:
				if(sleeping)
				{
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					sleeping = false;
				}
		        if(!isPlaying){
			        AudioPlayer.player.start(audioStream);
			        isPlaying = true;
			    }
				levelTwo.tick(gr);
				break;
			case LEVELCOMPLETE:
				levelComplete.tick(gr);
		default:
			break;	
				
		}
	}
	public static void stopMusic(){
		AudioPlayer.player.stop(audioStream);
	}
	
}
