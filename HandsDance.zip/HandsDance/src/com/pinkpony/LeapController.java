package com.pinkpony;

import com.leapmotion.*;
import com.leapmotion.leap.CircleGesture;
import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Finger;
import com.leapmotion.leap.FingerList;
import com.leapmotion.leap.Frame;
import com.leapmotion.leap.Gesture;
import com.leapmotion.leap.GestureList;
import com.leapmotion.leap.Hand;
import com.leapmotion.leap.SwipeGesture;
import com.leapmotion.leap.Vector;
import com.leapmotion.leap.Listener;


public class LeapController extends Listener{

	public char detectedChar;
	
	 public char getDetectedChar() {
		return detectedChar;
	}

	public void setDetectedChar(char detectedChar) {
		this.detectedChar = detectedChar;
	}

	public void onInit(Controller controller) {
	        System.out.println("Initialized");
	    }

	    public void onConnect(Controller controller) {
	        System.out.println("Connected");
	        //controller.enableGesture(Gesture.Type.TYPE_SWIPE);
	    }

	    public void onDisconnect(Controller controller) {
	        //Note: not dispatched when running in a debugger.
	        System.out.println("Disconnected");
	    }

	    public void onExit(Controller controller) {
	        System.out.println("Exited");
	    }

	    public void onFrame(Controller controller) {
	        // Get the most recent frame and report some basic information    	
	        Frame frame = controller.frame();
	        if (!frame.hands().isEmpty()) {
	            // Get the first hand
	            Hand hand = frame.hands().get(0);

	            // Check if the hand has any fingers
	            FingerList fingers = hand.fingers();
	        }
	        if (!frame.hands().isEmpty() ) {
	        char v = detectSign(frame);
	         // System.out.println("Char is : " + v);
	        }
	    }

	   public char detectSign(Frame frame){
		  
		   char c = '5';
		   Hand hand = frame.hands().get(0);
		   if(isAlphabetV(hand))
		   {
			   setDetectedChar('2');
		   return '2';
		   }
		   else if(isAlphabetY(hand))
		   {
			   setDetectedChar('3');
		   return '3';
		   }
		   else if(isAlphabet5(hand))
		   {
			   setDetectedChar('4');
		   return '4';
		   }
		   else if(isAlphabetI(hand))
		   {
			   setDetectedChar('1');
		   return '1';
		   }
		   else if (isAlphabet0(hand))
		   {
			   if(hand.fingers().count()==0)
				   setDetectedChar('0');
			   return '0';
		   }
		   setDetectedChar(c);
		   return c;  
	   }
	   
	   public boolean isAlphabetV(Hand hand)
	   {
		   /*
			Palm orientation : facing front
			Palm angle: vertical to device
			No. of fingers : 2
			Finger 1 angle : 45-90
			Finger 2 angle : 135-90
			Finger 1 angle from palm direction : 0-20
			Finger 2 angle from palm direction : 0-20
			Angle between two fingers : 15-40
			FingerTip Position: y co-ordinate almost same, x will vary.
		    */
		   	
		   	if(hand.fingers().count()==2)
		   	{
		   		Finger index = hand.fingers().leftmost();
		   		Finger middle = hand.fingers().rightmost();
		   		Vector indexVector = index.direction();
		   		Vector middleVector = middle.direction();
		   		
		   		//find angle between index and middle finger
		   		float angle = indexVector.angleTo(middleVector);
				double degrees = Math.toDegrees(angle);
				
				if(degrees > 10 && degrees < 40) {
					//return true;
					////check fingertip  postion

					Vector indexTip =  index.stabilizedTipPosition();
					Vector middleTip = middle.stabilizedTipPosition();

					int Y_ALLOWED_DIFF = 20;
					if(Math.abs(indexTip.getY() - middleTip.getY()) < Y_ALLOWED_DIFF)
					{
						return true;
					}
				}
		   	}
			return false;
	   }
	   public boolean isAlphabetL(Hand hand)
	   {
		   /*
			Palm orientation : facing front
			Palm angle: vertical to device
			No. of fingers : 2
			Finger 1 angle : 180 (horizontal)
			Finger 2 angle : 90 (vertical)
			Finger 1 angle from palm direction : 90
			Finger 2 angle from palm direction : 0
			Angle between two fingers : 90
			The 2nd finger is to the left of the palm's center(x coordinate)
			(all angles are in approx)
		    */
		   	
		   	if(hand.fingers().count()==2)
		   	{
		   		Finger thumb = hand.fingers().leftmost();
		   		Finger index = hand.fingers().rightmost();
		   		
		   		Vector thumbVector = thumb.direction();
		   		Vector indexVector = index.direction();
		   		
		   		//find angle between index and middle finger
		   		float angle = thumbVector.angleTo(indexVector);
				double degrees = Math.toDegrees(angle);
				
				if(degrees >40 && degrees < 110)
				{ 
					float indexX = index.tipPosition().getX();
					float palmX = hand.palmPosition().getX();
					if(indexX < palmX)
					{
						return true;
					}
				}
		   	}
			return false;
	   }
	   
	   public boolean isAlphabetY(Hand hand)
	   {
		   /*
			Palm orientation : facing front
			Palm angle: vertical to device
			No. of fingers : 2
			Finger 1 angle : 180 (horizontal)
			Finger 2 angle : 0 (vertical)
			Finger 1 angle from palm direction : 90
			Finger 2 angle from palm direction : 90
			Angle between two fingers : 180
			The 2nd finger is to the right of the palm's centre(x coordinate)
			(all angles are in approx)
		    */
		   	
		   	if(hand.fingers().count()==2)
		   	{
		   		Finger thumb = hand.fingers().leftmost();
		   		Finger pinky = hand.fingers().rightmost();
		   		Vector thumbVector = thumb.direction();
		   		Vector pinkyVector = pinky.direction();
		   		
		   		//find angle between index and middle finger
		   		float angle = thumbVector.angleTo(pinkyVector);
				double degrees = Math.toDegrees(angle);
				
				if(degrees >45 && degrees < 90)
				{
					float indexX = pinky.tipPosition().getX();
					float palmX = hand.palmPosition().getX();
					if(pinky.tipPosition().getX() > hand.palmPosition().getX())
					{
						return true;
					}
				}
		   	}
			return false;
	   }
	   
	   public boolean isAlphabet5(Hand hand)
	   {
		   /*
			Palm orientation : facing front
			All Pointables Visible
		    */
		   	
		   	if(hand.fingers().count()==5)
		   	{
		   		return true;
		   	}
			return false;
	   }
	   
	   public boolean isAlphabet0(Hand hand)
	   {
		   /*
			Palm orientation : facing front
			All Pointables Visible
		    */
		   	
		   	if(hand.fingers().count()<1)
		   	{
		   		return true;
		   	}
			return false;
	   }
	   
	   public boolean isAlphabetI(Hand hand)
	   {
		   /*
			Palm orientation : facing front
			Palm angle: vertical to device
			No. of fingers : 1
			
		    */
		   	
		   	if(hand.fingers().count()==1)
		   	{
		   		Finger index = hand.fingers().leftmost();
		   		//Finger index2 = hand.fingers().rightmost();
		   		//Vector indexVector = index.direction();
		   		
		   		if(index.tipPosition().getX() > hand.palmPosition().getX())
				{
					return true;
				}
		   		return true;
		   	}
			return false;
	   }
	   
}