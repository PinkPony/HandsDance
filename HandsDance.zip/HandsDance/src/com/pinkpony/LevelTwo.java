package com.pinkpony;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;
import com.leapmotion.leap.Controller;

public class LevelTwo extends AbstractGameState{

	Graphics gr;
	Random r;
	public int[] lvl = new int[30];
	public int[] hand = {1,2,3,4,5};
	public Image[] handImg = new Image[5];
	public Image[] hitImg = new Image[5];
	public Image[] boxImg = new Image[6];
	public Image backgroundImg;
	public int[] xPos = {30, 244, 465, 696, 920};
	public int[] yPos = {521, 501, 505, 525, 502};
	public char[] gestureChars = {'0', '1', '2', '3', '4'};
	public int[] hit = {0, 0, 0, 0, 0};
	public int currentIndex = 0;
	public int tickCount = 0;
	
	//+1
	public Image plusOne;
	
	// LEVEL TWO NEW NODES
	
	public int[] imgIndices = {0,1,0,1,2,1,2,3,4,2,3,4,3,4,3,2,3,2,1,2,1,
			0,1,0,1,2,1,2,3,4,2,3,4,3,4,3,2,3,2,1,2,1,
			0,1,0,1,2,1,2,3,4,2,3};
	public int noteCount = 54;
	
	public int spd = 20;
	public int fskip = 0;
	
	public int imgy = -200;	
	
	//FINAL SCORES
	public int score = 0;
	
	LeapController leapController;
	Controller controller;
	Music music;
	
	public LevelTwo()
	{
		lvl = generateLevel();
		leapController = new LeapController();
		controller = new Controller();
		controller.addListener(leapController);
		
		
		backgroundImg = Art.getImageFromFile("./images/playscreen.png");
		
		for (int i = 0; i < 5; i++) {
			
			handImg[i] = Art.getImageFromFile("./images/" + (i + 1) + ".png");
			hitImg[i] = Art.getImageFromFile("./images/hit_" + (i + 1) + ".png");
			boxImg[i] = Art.getImageFromFile("./images/box_" + (i + 1) + ".png");
		}
		
		boxImg[5] = Art.getImageFromFile("./images/box_z.png");
		
		plusOne = Art.getImageFromFile("./images/plusone.png");
	}
	
	@Override
	public void tick(Graphics g) {
		gr = g;
		
		// Clear the screen
		gr.clearRect(0, 0, HandsDance.WIDTH, HandsDance.HEIGHT);
		
		// Draw the background
		gr.drawImage(backgroundImg, 0, 0, HandsDance.WIDTH, HandsDance.HEIGHT, null);

		gr.drawImage(boxImg[Character.getNumericValue(leapController.getDetectedChar())], 1128, 28, 200, 200, null);
		
		//gr.drawString(""+Character.getNumericValue(leapController.getDetectedChar()), HandsDance.mouse[4], HandsDance.mouse[5]);
		gr.setColor(new Color(65,85,94));
		gr.setFont(new Font("Santa Fe LET", Font.PLAIN, 40));
		int scorex = 1210;
		int scorey = 450;
		gr.drawString(String.valueOf(score), scorex, scorey);
		gr.setColor(Color.white);
		
		/*if (tickCount > 0) {
			gr.drawString(String.valueOf(score/tickCount), scorex, scorey-70);
		} else {
			gr.drawString(String.valueOf(0), scorex, scorey-70);
		}*/
		
		//note count
		//gr.drawString(" / " +String.valueOf(noteCount), scorex+5, scorey);
		
		if (imgy > yPos[imgIndices[currentIndex]] - 20 && imgy < yPos[imgIndices[currentIndex]] + 20 && 
				leapController.getDetectedChar() == gestureChars[imgIndices[currentIndex]]){
			imgy = -600;
			hit[imgIndices[currentIndex]] = 5;
			gr.drawImage(hitImg[imgIndices[currentIndex]], xPos[imgIndices[currentIndex]], yPos[imgIndices[currentIndex]], 160, 200, null);
			score++;
			gr.drawImage(plusOne, xPos[imgIndices[currentIndex]], 680, 160, 100, null);
		} else {
			// Falling signs
			gr.drawImage(handImg[imgIndices[currentIndex]], xPos[imgIndices[currentIndex]], imgy, 160, 200, null);
			
			for (int i = 0; i < 5; i++) {
				if (hit[i] > 0) {
					gr.drawImage(hitImg[i], xPos[i], yPos[i], 160, 200, null);
					gr.drawImage(plusOne, xPos[i], 680, 160, 100, null);
					hit[i]--;
					
				}
			}
			
			imgy += spd;
			
			if(fskip == 40)
			{
				currentIndex++;
				imgy = -200;
				fskip = 0;
			} 
			else
			{
				fskip++;
			}
		}
		
		if(currentIndex >= noteCount - 1)
		{
			StateChanger.stopMusic();
			StateChanger.gameState = GameState.EXIT;
		}
		
		tickCount++;
	}

	public int[] generateLevel()
	{

		int[] ret = {1,2,3,4,5};

		return ret;
	}

}
