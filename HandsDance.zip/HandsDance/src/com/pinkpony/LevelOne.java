package com.pinkpony;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Random;


import com.leapmotion.leap.Controller;



public class LevelOne extends AbstractGameState{

	Graphics gr;
	Random r;
	public int[] lvl = new int[30];
	public int[] hand = {1,2,3,4,5};
	public Image[] handImg = new Image[5];
	public Image[] hitImg = new Image[5];
	public Image[] boxImg = new Image[6];
	public Image backgroundImg;
	public int[] xPos = {30, 244, 465, 696, 920};
	public int[] yPos = {521, 501, 505, 525, 501};
	public char[] gestureChars = {'0', '1', '2', '3', '4'};
	public int[] hit = {0, 0, 0, 0, 0};
	public int currentIndex = 0;
	
	public int spd = 10;
	public int fskip = 0;
	
	public int imgy = -200;	
	
	LeapController leapController;
	Controller controller;
	
	public LevelOne()
	{
		lvl = generateLevel();
		leapController = new LeapController();
		controller = new Controller();
		controller.addListener(leapController);
		
		backgroundImg = Art.getImageFromFile("./images/playscreen.png");
		
		for (int i = 0; i < 5; i++) {
			handImg[i] = Art.getImageFromFile("./images/" + (i + 1) + ".png");
			hitImg[i] = Art.getImageFromFile("./images/hit_" + (i + 1) + ".png");
			boxImg[i] = Art.getImageFromFile("./images/box_" + (i + 1) + ".png");
		}
		
		boxImg[5] = Art.getImageFromFile("./images/box_z.png");
	}
	
	@Override
	public void tick(Graphics g) {
		gr = g;
		
		// Clear the screen
		gr.clearRect(0, 0, HandsDance.WIDTH, HandsDance.HEIGHT);
		
		// Draw the background
		gr.drawImage(backgroundImg, 0, 0, HandsDance.WIDTH, HandsDance.HEIGHT, null);

		gr.drawImage(boxImg[Character.getNumericValue(leapController.getDetectedChar())], 1128, 28, 200, 200, null);
		
		//gr.drawString(""+Character.getNumericValue(leapController.getDetectedChar()), HandsDance.mouse[4], HandsDance.mouse[5]);
				
		if (imgy > yPos[currentIndex] - 30 && imgy < yPos[currentIndex] + 30 && 
				leapController.getDetectedChar() == gestureChars[currentIndex]){
			imgy = -200;
			fskip = 0;
			hit[currentIndex] = 7;
			gr.drawImage(hitImg[currentIndex], xPos[currentIndex], yPos[currentIndex], 160, 200, null);
			currentIndex++;
		} else {
			// Falling signs
			gr.drawImage(handImg[currentIndex], xPos[currentIndex], imgy, 160, 200, null);
			
			for (int i = 0; i < 5; i++) {
				if (hit[i] > 0) {
					gr.drawImage(hitImg[i], xPos[i], yPos[i], 160, 200, null);
					hit[i]--;
					//System.out.println(hit[i]);
				}
			}
			
			if(fskip % 1 == 0)
			{
				imgy+= spd;
			}
			if(fskip == 85)
			{
				imgy = -200;			
				fskip = 0;
			} else
			{
				fskip++;
			}
		}
		System.out.println(currentIndex);
		if(currentIndex >=5)
		{
			StateChanger.gameState = GameState.LEVELCOMPLETE;
			
		}
	}

	public int[] generateLevel()
	{

		int[] ret = {1,2,3,4,5};

		return ret;
	}

}
