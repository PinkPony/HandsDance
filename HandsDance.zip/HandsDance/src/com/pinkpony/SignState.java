package com.pinkpony;

public enum SignState {

	kNotStarted,
	kWaiting;
	
	
}
