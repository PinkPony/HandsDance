package com.pinkpony;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class Music
{
    /**
     * The audio stream to play .wav files.
     */
    private AudioStream audioStream;
	private boolean isPlaying = false;
   
    /**
     * Plays music with fileName.
     * @param filename
     * @throws IOException
     */
    public void musicStart(String filename) throws IOException
    {
    	InputStream in = new FileInputStream(new File(filename));
        audioStream = new AudioStream(in);
        if(!isPlaying){
        AudioPlayer.player.start(audioStream);
        isPlaying = true;
        }
    }

    /**
     * Stops audio stream.
     * @throws IOException
     */
    public void musicStop() throws IOException
    {
        AudioPlayer.player.stop(audioStream);
    }
   
}