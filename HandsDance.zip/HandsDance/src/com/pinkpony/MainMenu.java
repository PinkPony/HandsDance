package com.pinkpony;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Gesture.Type;

public class MainMenu extends AbstractGameState{


	LeapStartGamePlay leapStartGamePlay;
	Controller controller;
	
	public MainMenu(){
		leapStartGamePlay = new LeapStartGamePlay();
		controller = new Controller();
		controller.addListener(leapStartGamePlay);
		
			
	 }
	
	Graphics gr;
	public void tick(Graphics g)
	{
		gr = g;
		gr.clearRect(0, 0, HandsDance.WIDTH, HandsDance.HEIGHT);
		
		Image mainlogo = Art.getImageFromFile("./images/titlescreen.png");
		gr.drawImage(mainlogo, 0, 0, HandsDance.WIDTH, HandsDance.HEIGHT, null);
		
		
		gr.setColor(Color.white);
		gr.setFont(new Font("Santa Fe LET", Font.PLAIN, 22));
		
		gr.drawString("Hit Esc to Leave , TAP TO START", 10, 20);	
		//gr.drawString("IN MENU SCREEN",400,400);
		
		
		int mx = HandsDance.mouse[4];
		int my = HandsDance.mouse[5];
		String pos = "x:"+mx + " y:"+my;
		System.out.println(pos);
		
		//gr.drawString(pos, mx, my);
		boolean xplay = HandsDance.mouse[4] >= 598 && HandsDance.mouse[4] <= 803;
		boolean yplay = HandsDance.mouse[5] >= 577 && HandsDance.mouse[5] <= 695;
		
		
		if(xplay && yplay && HandsDance.mouse[0] != 0)
			{
			play();
			}	
	}
	public void play()
	{
		controller.removeListener(leapStartGamePlay);
		controller.enableGesture(Type.TYPE_KEY_TAP, false);
		StateChanger.gameState = GameState.PLAY;	
	}
}
