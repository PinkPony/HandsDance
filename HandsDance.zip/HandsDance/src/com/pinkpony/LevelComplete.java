package com.pinkpony;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

public class LevelComplete extends AbstractGameState {

	@Override
	public void tick(Graphics g) {
		// TODO Auto-generated method stub
		gr = g;
		gr.clearRect(0, 0, HandsDance.WIDTH, HandsDance.HEIGHT);
		
		Image mainlogo = Art.getImageFromFile("./images/levelcomplete.png");
		gr.drawImage(mainlogo, 0, 0, HandsDance.WIDTH, HandsDance.HEIGHT, null);
		
		gr.drawString("Hit Esc to Leave", 10, 20);	

		gr.setColor(new Color(65,85,94));
		//gr.setFont(new Font("SansSerif", Font.PLAIN, 40));
		gr.setFont(new Font("Santa Fe LET", Font.PLAIN, 32));
		int scorex = 555;
		int scorey = 450;
		//gr.drawString(String.valueOf(score), scorex, scorey);
		gr.setColor(Color.white);
		gr.drawString("Wait for Next Level", scorex+3, scorey-3);
		
		StateChanger.gameState = GameState.LEVELTWO;
		
	
	}

}
